package tech.jaykay12.sbheroku;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunnerApplicationTest {

	@Test
	void contextLoads() {
	}

}
