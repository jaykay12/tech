package tech.jaykay12;

public class Calculator {
    public Integer adder(Integer a1, Integer a2) {
        return a1+a2;
    }

    public Integer adder(Integer a1, Integer a2, Integer a3) {
        return a1+a2+a3;
    }
}
