package tech.jaykay12;

public interface StockService {
    public float getRealtimePrice(String name);
}
