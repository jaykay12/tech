const express = require('express')
const app = express()
const port = 9211

app.get('/', (req, res) => res.send('nodeJS API Running!'))

app.listen(port, () => console.log(`nodeJS app listening at http://localhost:${port}`))
